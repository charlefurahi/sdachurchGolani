<template>
  <div class="min-h-screen bg-gray-50 dark:bg-navy-950">

    <!-- Hero / breadcrumb -->
    <div class="page-hero">
      <div class="page-hero__inner">
        <div class="container-custom">
          <Breadcrumbs :crumbs="[{ to: '/announcements', label: 'Announcements' }, { label: announcement?.title || 'Announcement' }]" />
        </div>
      </div>
    </div>

    <div class="container-custom py-10">

      <!-- Loading -->
      <div v-if="loading" class="max-w-3xl mx-auto space-y-4 animate-pulse">
        <div class="h-4 bg-gray-200 dark:bg-navy-700 rounded w-1/3"></div>
        <div class="h-8 bg-gray-200 dark:bg-navy-700 rounded w-3/4"></div>
        <div class="h-64 bg-gray-200 dark:bg-navy-700 rounded-2xl"></div>
      </div>

      <!-- Not found -->
      <div v-else-if="!announcement" class="text-center py-24">
        <div class="text-7xl mb-4">📢</div>
        <h2 class="font-heading text-2xl text-navy-800 dark:text-white mb-2">Announcement Not Found</h2>
        <p class="text-gray-400 mb-6">This announcement may have been removed or expired.</p>
        <RouterLink to="/announcements" class="btn-primary">← Back to Announcements</RouterLink>
      </div>

      <!-- Announcement content -->
      <div v-else class="max-w-3xl mx-auto">

        <!-- Meta row: category + badges -->
        <div class="flex flex-wrap items-center gap-2 mb-3">
          <span v-if="announcement.category" class="badge-primary">{{ announcement.category }}</span>
          <span v-if="announcement.priority === 'urgent'" class="ad-badge ad-badge--urgent">🚨 Urgent</span>
          <span v-if="announcement.is_pinned" class="ad-badge ad-badge--pinned">📌 Pinned</span>
        </div>

        <!-- Title -->
        <h1 class="font-heading text-2xl md:text-3xl font-bold text-navy-800 dark:text-white mb-3 leading-tight">
          {{ announcement.title }}
        </h1>

        <!-- Date -->
        <p class="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-8">
          <svg class="w-4 h-4 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
          {{ formatDate(announcement.announcement_date || announcement.created_at) }}
        </p>

        <!-- PDF document panel -->
        <div v-if="pdfUrl" class="ad-doc">
          <div class="ad-doc__icon">
            <img :src="pdfLogo" alt="" />
          </div>
          <div class="ad-doc__info">
            <p class="ad-doc__label">PDF Document</p>
            <p class="ad-doc__filename">{{ announcement.title }}.pdf</p>
          </div>
          <div class="ad-doc__actions">
            <a :href="pdfUrl" target="_blank" rel="noopener" class="btn-primary btn-sm text-center">
              Open PDF ↗
            </a>
            <a :href="pdfUrl" :download="`${announcement.title}.pdf`" class="btn-secondary btn-sm text-center">
              ⬇ Download
            </a>
          </div>
        </div>

        <!-- Inline preview (desktop) -->
        <div v-if="pdfUrl" class="ad-preview">
          <p class="ad-preview__label">Preview</p>
          <iframe :src="pdfUrl" class="ad-preview__frame" title="PDF preview"></iframe>
          <p class="ad-preview__hint">
            Can't see the preview? <a :href="pdfUrl" target="_blank" rel="noopener">Open the PDF directly →</a>
          </p>
        </div>

        <!-- Text fallback — only when there is no PDF attached -->
        <div v-else class="bg-white dark:bg-navy-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-navy-700">
          <p class="text-gray-600 dark:text-gray-300 leading-relaxed whitespace-pre-line">
            {{ announcement.content || announcement.summary || 'No further details were provided for this announcement.' }}
          </p>
        </div>

        <div class="mt-8">
          <RouterLink to="/announcements" class="btn-secondary btn-sm">← All Announcements</RouterLink>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import { formatDate } from '@/utils/index.js'
import announcementService from '@/services/announcementService'
import { announcements as demoAnnouncements } from '@/data/announcements.js'
import Breadcrumbs from '@/components/common/Breadcrumbs.vue'
import pdfLogo from '@/assets/logos/pdf.png'

const BASE_URL = import.meta.env.VITE_API_BASE_URL?.replace('/api/v1', '') || 'http://127.0.0.1:8000'
const route = useRoute()

const announcement = ref(null)
const loading = ref(false)

onMounted(async () => {
  loading.value = true
  try {
    announcement.value = await announcementService.getById(route.params.id)
  } catch {
    // API unreachable or record not found yet — fall back to demo data so
    // the page still works before the backend has real announcements.
    announcement.value = demoAnnouncements.find(a => String(a.id) === String(route.params.id)) || null
  } finally {
    loading.value = false
  }
})

// pdf_file_url is treated as already-absolute (that's the convention used
// by the admin panel and the public list), but this falls back to
// prefixing the API host if a relative path ever comes through.
const pdfUrl = computed(() => {
  const src = announcement.value?.pdf_file_url
  if (!src) return null
  return src.startsWith('http') ? src : BASE_URL + src
})
</script>

<style scoped>
.ad-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  padding: 0.25rem 0.65rem;
  border-radius: 999px;
}
.ad-badge--pinned { background: #fdf3c4; color: #8c6f1a; }
:global(.dark) .ad-badge--pinned { background: rgba(244,208,63,0.15); color: #f4d03f; }
.ad-badge--urgent { background: #fee2e2; color: #b91c1c; }
:global(.dark) .ad-badge--urgent { background: rgba(220,38,38,0.2); color: #f87171; }

/* ── Document panel ───────────────────────────────────────── */
.ad-doc {
  display: flex;
  align-items: center;
  gap: 1rem;
  background: #fff;
  border: 1px solid rgba(226,232,240,0.9);
  border-radius: 1.25rem;
  padding: 1.25rem 1.5rem;
  box-shadow: 0 2px 16px rgba(10,22,40,0.06);
  margin-bottom: 1.5rem;
  flex-wrap: wrap;
}
:global(.dark) .ad-doc { background: #0f2233; border-color: rgba(255,255,255,0.08); }
.ad-doc__icon {
  flex-shrink: 0;
  width: 52px;
  height: 52px;
  border-radius: 0.9rem;
  background: #f2f4f6;
  display: flex;
  align-items: center;
  justify-content: center;
}
:global(.dark) .ad-doc__icon { background: rgba(255,255,255,0.06); }
.ad-doc__icon img { width: 30px; height: 30px; object-fit: contain; }
.ad-doc__info { flex: 1; min-width: 160px; }
.ad-doc__label {
  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: #b38f22;
  margin: 0 0 0.15rem;
}
:global(.dark) .ad-doc__label { color: #f4d03f; }
.ad-doc__filename {
  font-weight: 600;
  color: #0d2137;
  margin: 0;
  word-break: break-word;
}
:global(.dark) .ad-doc__filename { color: #fff; }
.ad-doc__actions {
  display: flex;
  gap: 0.6rem;
  flex-shrink: 0;
  flex-wrap: wrap;
}

/* ── Inline preview ───────────────────────────────────────── */
.ad-preview { margin-bottom: 1.5rem; }
.ad-preview__label {
  font-size: 0.7rem;
  font-weight: 700;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  color: #6b7280;
  margin: 0 0 0.5rem;
}
:global(.dark) .ad-preview__label { color: rgba(255,255,255,0.5); }
.ad-preview__frame {
  width: 100%;
  height: 70vh;
  min-height: 420px;
  border: 1px solid rgba(226,232,240,0.9);
  border-radius: 1rem;
  background: #f2f4f6;
}
:global(.dark) .ad-preview__frame { border-color: rgba(255,255,255,0.08); background: #0f2233; }
.ad-preview__hint {
  font-size: 0.78rem;
  color: #9ca3af;
  margin-top: 0.5rem;
  text-align: center;
}
.ad-preview__hint a { color: #b38f22; font-weight: 600; }
:global(.dark) .ad-preview__hint a { color: #f4d03f; }

/* PDF iframes are unreliable on small/touch screens — lean on the
   document panel's Open/Download buttons there instead. */
@media (max-width: 640px) {
  .ad-preview { display: none; }
}
</style>