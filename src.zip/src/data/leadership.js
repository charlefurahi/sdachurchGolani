/**
 * Leadership — demo/seed data.
 *
 * Used as an API-fallback only: pages call the matching *Service.js first;
 * this file supplies content when the API has no records yet (e.g. during
 * early setup or local development without a backend). Once the API is
 * returning real records, this file is never read.
 */

export const leadership = [
  {
    id: 1,
    name: 'Pastor Godliven Ngessi',
    title: 'Senior Pastor',
    bio: 'Pastor Ngessi has served Chuokikuu Street for over 1 years.',
    email: 'pastor@golanisda.org',
    avatar: null,
  },
  {
    id: 2,
    name: 'Elder Emmanuel Kamba',
    title: 'Head Elder',
    bio: 'Elder Kamba leads the board of elders and oversees the spiritual direction of the church. He has been a pillar of GolaniSDA for over 20 years.',
    email: 'elder@golanisda.org',
    avatar: null,
  },
  {
    id: 3,
    name: 'Br. Reuben Mmato',
    title: 'Church Secretary',
    bio: 'Brother Reuben coordinates church administration, member records, and communications. She brings warmth and excellence to everything she does.',
    email: 'secretary@golanisda.org',
    avatar: null,
  },
  {
    id: 4,
    name: 'Brother Cyprian Kabanza',
    title: 'Church Treasurer',
    bio: 'Brother Kabanza oversees the church finances with integrity and transparency. He is a certified accountant and has served in this role for 8 years.',
    email: 'treasurer@golanisda.org',
    avatar: null,
  },
  {
    id: 5,
    name: 'Br. Yoeza Kilenga',
    title: 'Stewardship Leader',
    bio: 'Brother Yoeza leads the youth and young adult ministry with energy and vision. She is dedicated to nurturing the next generation of Adventist leaders.',
    email: 'youth@golanisda.org',
    avatar: null,
  },
  {
    id: 6,
    name: 'Elder Peter Boniface',
    title: 'Church Elderr',
    bio: 'Elder Peter coordinates all community service programs, health fairs, and mission initiatives. He has a heart for the least and the lost.',
    email: 'outreach@golanisda.org',
    avatar: null,
  },
]