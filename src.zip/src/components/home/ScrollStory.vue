<template>
  <section
    ref="storyRef"
    class="scroll-story"
    :style="{ '--story-image': `url(${image})` }"
    aria-label="Golani church story"
  >
    <div class="scroll-story__sequence">
      <article
        v-for="(panel, index) in panels"
        :key="panel"
        class="scroll-story__item"
        :class="`scroll-story__item--${index}`"
      >
        <div class="scroll-story__item-inner">
          <span class="scroll-story__index" aria-hidden="true">
            0{{ index + 1 }}
          </span>
          <div class="scroll-story__slot">
            <slot :name="`panel-${index}`" />
          </div>
        </div>
      </article>
    </div>
  </section>
</template>

<script setup>
import { onBeforeUnmount, onMounted, ref } from 'vue'

const props = defineProps({
  image: {
    type: String,
    required: true
  }
})

const panels = ['welcome', 'church-life', 'worship']
const storyRef = ref(null)
let observer

onMounted(() => {
  if (!storyRef.value || typeof IntersectionObserver === 'undefined') return

  observer = new IntersectionObserver(
    entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('is-visible')
      })
    },
    { threshold: 0.14 }
  )

  storyRef.value
    .querySelectorAll('.scroll-story__item')
    .forEach(item => observer.observe(item))
})

onBeforeUnmount(() => {
  observer?.disconnect()
})
</script>

<style scoped>
/*
 * IMPORTANT:
 * This component intentionally does NOT use a sticky viewport.
 * The reference behaves like a real page: each section occupies its
 * own place in the document and naturally scrolls away.
 */
.scroll-story {
  --story-gutter: clamp(1.25rem, 4vw, 4rem);
  --story-max: 1240px;
  width: 100%;
  overflow: clip;
  background: var(--color-white);
}

.scroll-story__sequence {
  width: 100%;
}

.scroll-story__item {
  position: relative;
  width: 100%;
  isolation: isolate;
}

.scroll-story__item-inner {
  position: relative;
  width: min(100%, var(--story-max));
  margin: 0 auto;
}

.scroll-story__slot {
  width: 100%;
}

/* Small editorial marker — not a fixed navigation element. */
.scroll-story__index {
  position: absolute;
  top: clamp(1.25rem, 3vw, 2rem);
  right: var(--story-gutter);
  z-index: 4;
  font-size: 0.68rem;
  line-height: 1;
  font-weight: 800;
  letter-spacing: 0.16em;
  opacity: 0.5;
  pointer-events: none;
}

.scroll-story__item--0 {
  background: var(--color-white);
}

.scroll-story__item--1 {
  background: var(--color-navy);
}

/*
 * The photograph is a NORMAL section, not a fixed page background.
 * Home.vue supplies .story-panel--image on panel 3.
 */
.scroll-story__item--2 {
  background: var(--color-navy-deep, var(--color-navy));
}

.scroll-story__item :deep(.story-panel) {
  min-height: 0;
}

.scroll-story__item :deep(.story-panel--light) {
  background: var(--color-white);
}

.scroll-story__item :deep(.story-panel--navy) {
  background: var(--color-navy);
}

.scroll-story__item :deep(.story-panel--image) {
  position: relative;
  background-image:
    linear-gradient(rgba(9, 29, 43, 0.62), rgba(9, 29, 43, 0.62)),
    var(--story-image);
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

/* Subtle reveal only when the section actually enters the viewport. */
.scroll-story__item .story-panel__inner {
  opacity: 0;
  transform: translateY(22px);
  transition:
    opacity 650ms ease,
    transform 650ms cubic-bezier(0.22, 1, 0.36, 1);
}

.scroll-story__item.is-visible .story-panel__inner,
.scroll-story__item:first-child .story-panel__inner {
  opacity: 1;
  transform: none;
}

@media (max-width: 900px) {
  .scroll-story__index {
    right: 1.25rem;
  }

  .scroll-story__item :deep(.story-panel--image) {
    background-position: 58% center;
  }
}

@media (prefers-reduced-motion: reduce) {
  .scroll-story__item .story-panel__inner {
    opacity: 1;
    transform: none;
    transition: none;
  }
}
</style>
