<template>
  <article class="sermon-card group">
    <!-- Image -->
    <div class="sermon-card__media">
      <img
        v-if="thumbSrc"
        :src="thumbSrc"
        :alt="sermon.title"
        class="sermon-card__image"
        @error="thumbError = true"
      />

      <!-- Image fallback -->
      <div
        v-else
        class="sermon-card__placeholder"
        aria-hidden="true"
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="1.5"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            d="M12 18.75a6.75 6.75 0 0 0 6.75-6.75V8.25a6.75 6.75 0 1 0-13.5 0V12A6.75 6.75 0 0 0 12 18.75Zm0 0v3m-3 0h6"
          />
        </svg>
      </div>

      <!-- Dark overlay -->
      <div
        v-if="thumbSrc"
        class="sermon-card__overlay"
        aria-hidden="true"
      ></div>

      <!-- Featured -->
      <div
        v-if="sermon.featured || sermon.is_featured"
        class="sermon-card__featured"
      >
        Featured
      </div>

      <!-- Duration -->
      <div
        v-if="sermon.duration || sermon.duration_display"
        class="sermon-card__duration"
      >
        {{ sermon.duration_display || sermon.duration }}
      </div>

      <!-- Play button -->
      <RouterLink
        :to="`/sermons/${sermon.id}`"
        class="sermon-card__play"
        :aria-label="`Listen to ${sermon.title}`"
      >
        <svg
          viewBox="0 0 24 24"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M8.25 5.25v13.5L19.5 12 8.25 5.25Z" />
        </svg>
      </RouterLink>
    </div>

    <!-- Content -->
    <div class="sermon-card__body">
      <p class="sermon-card__category">
        {{ categoryLabel }}
      </p>

      <h3 class="sermon-card__title">
        {{ sermon.title }}
      </h3>

      <p
        v-if="resolvedSpeaker"
        class="sermon-card__speaker"
      >
        {{ resolvedSpeaker }}
      </p>

      <p
        v-if="sermon.scripture || sermon.scripture_reference"
        class="sermon-card__scripture"
      >
        {{ sermon.scripture || sermon.scripture_reference }}
      </p>

      <!-- Footer -->
      <div class="sermon-card__footer">
        <div class="sermon-card__meta">
          <span v-if="sermon.preach_date || sermon.date">
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
              aria-hidden="true"
            >
              <rect
                x="3"
                y="5"
                width="18"
                height="16"
                rx="2"
              />
              <path d="M16 3v4M8 3v4M3 10h18" />
            </svg>

            {{ formatDate(sermon.preach_date || sermon.date) }}
          </span>

          <span>
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
              aria-hidden="true"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="M2.25 12s3.75-6.75 9.75-6.75S21.75 12 21.75 12 18 18.75 12 18.75 2.25 12 2.25 12Z"
              />
              <circle cx="12" cy="12" r="2.5" />
            </svg>

            {{ viewCount }}
          </span>
        </div>

        <RouterLink
          :to="`/sermons/${sermon.id}`"
          class="sermon-card__link"
        >
          Listen
          <span aria-hidden="true">→</span>
        </RouterLink>
      </div>
    </div>
  </article>
</template>

<script setup>
import { computed, ref } from 'vue'
import { RouterLink } from 'vue-router'
import { formatDate } from '@/utils/index.js'
import { resolveMedia } from '@/services/api.js'

const props = defineProps({
  sermon: {
    type: Object,
    required: true
  }
})

const thumbError = ref(false)

const thumbSrc = computed(() => {
  if (thumbError.value) return null

  if (props.sermon.thumbnail_url) {
    return props.sermon.thumbnail_url
  }

  if (props.sermon.thumbnail) {
    return resolveMedia(props.sermon.thumbnail)
  }

  return null
})

const resolvedSpeaker = computed(() => {
  const speaker = props.sermon.speaker

  if (!speaker) return ''

  if (typeof speaker === 'object') {
    return (
      speaker.full_name ||
      `${speaker.first_name || ''} ${speaker.last_name || ''}`.trim()
    )
  }

  return speaker
})

const categoryLabel = computed(() => {
  const category =
    props.sermon.category_display ||
    props.sermon.topic

  if (category) return category

  const rawCategory = props.sermon.category

  if (!rawCategory) return 'General'

  if (typeof rawCategory === 'object') {
    return rawCategory.name || 'General'
  }

  return rawCategory.charAt(0).toUpperCase() + rawCategory.slice(1)
})

const viewCount = computed(() => {
  const views =
    props.sermon.views_count ||
    props.sermon.views ||
    0

  return Number(views).toLocaleString()
})
</script>

<style scoped>
.sermon-card {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;

  background: var(--color-white, #ffffff);

  border: 1px solid rgba(13, 33, 55, 0.09);
  border-radius: 0;

  box-shadow: 0 8px 28px rgba(13, 33, 55, 0.05);

  transition:
    transform 280ms ease,
    box-shadow 280ms ease,
    border-color 280ms ease;
}

.sermon-card:hover {
  transform: translateY(-6px);

  border-color: rgba(212, 175, 55, 0.4);

  box-shadow: 0 20px 45px rgba(13, 33, 55, 0.12);
}


/* =========================
   MEDIA
========================= */

.sermon-card__media {
  position: relative;

  height: 220px;

  overflow: hidden;

  background:
    linear-gradient(
      135deg,
      var(--color-navy-deep, #0d2137),
      #173958
    );
}

.sermon-card__image {
  position: absolute;
  inset: 0;

  width: 100%;
  height: 100%;

  object-fit: cover;

  transition:
    transform 600ms ease,
    opacity 400ms ease;
}

.group:hover .sermon-card__image {
  transform: scale(1.06);
}

.sermon-card__overlay {
  position: absolute;
  inset: 0;

  background:
    linear-gradient(
      to top,
      rgba(13, 33, 55, 0.78),
      rgba(13, 33, 55, 0.1)
    );

  transition: background 300ms ease;
}

.group:hover .sermon-card__overlay {
  background:
    linear-gradient(
      to top,
      rgba(13, 33, 55, 0.65),
      rgba(13, 33, 55, 0.2)
    );
}


/* =========================
   FALLBACK
========================= */

.sermon-card__placeholder {
  position: absolute;
  inset: 0;

  display: grid;
  place-items: center;

  color: rgba(244, 208, 63, 0.25);
}

.sermon-card__placeholder svg {
  width: 70px;
  height: 70px;
}


/* =========================
   BADGES
========================= */

.sermon-card__featured {
  position: absolute;
  top: 1rem;
  left: 1rem;

  padding: 0.42rem 0.75rem;

  background: var(--color-gold, #d4af37);
  color: var(--color-navy-deep, #0d2137);

  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}

.sermon-card__duration {
  position: absolute;
  right: 1rem;
  bottom: 1rem;

  padding: 0.38rem 0.65rem;

  background: rgba(13, 33, 55, 0.88);
  color: var(--color-white, #ffffff);

  font-size: 0.72rem;
  font-weight: 600;

  backdrop-filter: blur(8px);
}


/* =========================
   PLAY BUTTON
========================= */

.sermon-card__play {
  position: absolute;
  top: 50%;
  left: 50%;

  display: grid;
  place-items: center;

  width: 58px;
  height: 58px;

  border: 1px solid rgba(255, 255, 255, 0.45);
  border-radius: 50%;

  background: var(--color-gold, #d4af37);
  color: var(--color-navy-deep, #0d2137);

  transform:
    translate(-50%, -50%)
    scale(0.88);

  opacity: 0;

  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);

  transition:
    opacity 250ms ease,
    transform 250ms ease,
    background 250ms ease;
}

.group:hover .sermon-card__play {
  opacity: 1;

  transform:
    translate(-50%, -50%)
    scale(1);
}

.sermon-card__play:hover {
  background: var(--color-white, #ffffff);
}

.sermon-card__play svg {
  width: 22px;
  height: 22px;

  margin-left: 3px;
}


/* =========================
   BODY
========================= */

.sermon-card__body {
  display: flex;
  flex: 1;
  flex-direction: column;

  padding: 1.5rem;
}

.sermon-card__category {
  margin-bottom: 0.8rem;

  color: var(--color-gold, #b89122);

  font-size: 0.68rem;
  font-weight: 700;
  letter-spacing: 0.12em;
  line-height: 1.4;
  text-transform: uppercase;
}

.sermon-card__title {
  display: -webkit-box;
  overflow: hidden;

  margin: 0;

  color: var(--color-navy-deep, #0d2137);

  font-family:
    var(--font-heading, 'Cormorant Garamond'),
    Georgia,
    serif;

  font-size: 1.35rem;
  font-weight: 700;
  line-height: 1.2;

  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;

  transition: color 220ms ease;
}

.group:hover .sermon-card__title {
  color: var(--color-gold, #b89122);
}

.sermon-card__speaker {
  margin-top: 0.8rem;

  color: rgba(13, 33, 55, 0.68);

  font-size: 0.82rem;
  font-weight: 600;
}

.sermon-card__scripture {
  margin-top: 0.45rem;

  color: var(--color-gold, #b89122);

  font-size: 0.8rem;
  font-style: italic;
  line-height: 1.5;
}


/* =========================
   FOOTER
========================= */

.sermon-card__footer {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 1rem;

  margin-top: auto;
  padding-top: 1.4rem;
}

.sermon-card__meta {
  display: flex;
  flex-direction: column;
  gap: 0.45rem;

  color: rgba(13, 33, 55, 0.48);

  font-size: 0.72rem;
}

.sermon-card__meta span {
  display: inline-flex;
  align-items: center;
  gap: 0.38rem;
}

.sermon-card__meta svg {
  width: 13px;
  height: 13px;

  flex-shrink: 0;
}

.sermon-card__link {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;

  color: var(--color-navy-deep, #0d2137);

  font-size: 0.78rem;
  font-weight: 700;
  text-decoration: none;

  white-space: nowrap;

  transition:
    color 200ms ease,
    gap 200ms ease;
}

.sermon-card__link span {
  color: var(--color-gold, #b89122);

  transition: transform 200ms ease;
}

.sermon-card__link:hover {
  gap: 0.6rem;

  color: var(--color-gold, #b89122);
}

.sermon-card__link:hover span {
  transform: translateX(2px);
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 640px) {
  .sermon-card__media {
    height: 200px;
  }

  .sermon-card__body {
    padding: 1.25rem;
  }

  .sermon-card__title {
    font-size: 1.2rem;
  }

  .sermon-card__play {
    opacity: 1;

    width: 50px;
    height: 50px;

    transform:
      translate(-50%, -50%)
      scale(1);
  }
}
</style>