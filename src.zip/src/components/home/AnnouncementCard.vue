<template>
  <article class="announcement-card group">
    <div class="announcement-card__preview">
      <div class="announcement-card__pdf">
        <img :src="pdfLogo" alt="PDF" />
        <span>PDF</span>
      </div>

      <div class="announcement-card__badges">
        <span v-if="announcement.category" class="badge-primary">{{ announcement.category }}</span>
        <span v-if="announcement.priority === 'urgent'" class="ad-badge ad-badge--urgent">Urgent</span>
        <span v-if="announcement.is_pinned" class="ad-badge ad-badge--pinned">Pinned</span>
      </div>
    </div>

    <div class="p-5 flex flex-col h-full">
      <p class="text-xs text-gray-500 dark:text-gray-400 mb-2">
        {{ formatDate(announcement.announcement_date || announcement.created_at) }}
      </p>

      <h3 class="font-heading text-lg font-bold text-navy-800 dark:text-white leading-snug mb-3">
        {{ announcement.title }}
      </h3>

      <p class="text-sm text-gray-500 dark:text-gray-400 leading-relaxed line-clamp-3 flex-1">
        {{ announcement.content || announcement.summary || 'View the attached announcement for full details.' }}
      </p>

      <button type="button" class="btn-primary btn-sm mt-5" @click="$emit('read-more', announcement)">
        Read More
      </button>
    </div>
  </article>
</template>

<script setup>
import { formatDate } from '@/utils/index.js'
import pdfLogo from '@/assets/logos/pdf.png'

defineProps({
  announcement: {
    type: Object,
    required: true,
  },
})

defineEmits(['read-more'])
</script>

<style scoped>
.announcement-card {
  display: flex;
  flex-direction: column;
  overflow: hidden;
  height: 100%;
  background: #fff;
  border: 1px solid #e8edf2;
  border-radius: 1rem;
  box-shadow: 0 5px 22px rgba(13, 33, 55, 0.06);
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.announcement-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 14px 32px rgba(13, 33, 55, 0.11);
}

:global(.dark) .announcement-card {
  background: #0f2233;
  border-color: rgba(255, 255, 255, 0.07);
}

.announcement-card__preview {
  position: relative;
  height: 140px;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, #10283f, #0d2137);
  overflow: hidden;
}

.announcement-card__preview::after {
  content: '';
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 80% 20%, rgba(201, 162, 39, 0.2), transparent 42%);
}

.announcement-card__pdf {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.35rem;
  color: #fff;
  font-size: 0.7rem;
  font-weight: 800;
  letter-spacing: 0.12em;
}

.announcement-card__pdf img {
  width: 46px;
  height: 46px;
  object-fit: contain;
}

.announcement-card__badges {
  position: absolute;
  z-index: 2;
  top: 0.75rem;
  left: 0.75rem;
  right: 0.75rem;
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
}

.ad-badge {
  display: inline-flex;
  align-items: center;
  padding: 0.25rem 0.6rem;
  border-radius: 999px;
  font-size: 0.65rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.ad-badge--urgent {
  background: #fee2e2;
  color: #b91c1c;
}

.ad-badge--pinned {
  background: #fdf3c4;
  color: #8c6f1a;
}
</style>