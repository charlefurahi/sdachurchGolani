<template>
  <div class="pillars-strip" aria-label="Church pillars">
    <div class="pillars-strip__track">

      <!-- First set -->
      <div
        v-for="pillar in pillars"
        :key="`${pillar.key}-one`"
        class="pillar-logo"
      >
        <img
          :src="pillar.img"
          alt=""
          aria-hidden="true"
        />
      </div>

      <!-- Duplicate set (for seamless loop) -->
      <div
        v-for="pillar in pillars"
        :key="`${pillar.key}-two`"
        class="pillar-logo"
      >
        <img
          :src="pillar.img"
          alt=""
          aria-hidden="true"
        />
      </div>

    </div>
  </div>
</template>

<script setup>
/*
  IMPORTANT: majina ya faili ni lowercase (.png),
  siyo .PNG. Kwenye Mac/Windows import ya .PNG
  inaweza "kufanya kazi" kwa bahati, lakini
  kwenye server nyingi za production (Linux,
  case-sensitive) build itavunjika. Tumia .png
  kila mahali.
*/
import iwillgo from '@/assets/gallery/IWILLGO.png'
import onevoice from '@/assets/gallery/ONEVOICE.png'
import grounded from '@/assets/gallery/GROUNDED.png'
import integrated from '@/assets/gallery/INTEGRATED.png'

const pillars = [
  { key: 'iwillgo', img: iwillgo },
  { key: 'onevoice', img: onevoice },
  { key: 'grounded', img: grounded },
  { key: 'integrated', img: integrated },
]
</script>

<style scoped>
/* =========================================================
   WHITE STRIP
   Hii inakalia chini ya HeroSection (position: absolute,
   bottom: 0) kwa sababu HeroSection ina position: relative.
========================================================= */

.pillars-strip {
  position: absolute;
  left: 0;
  bottom: 0;

  width: 100%;
  height: 132px;

  background: #ffffff;

  overflow: hidden;

  display: flex;
  align-items: center;

  z-index: 10;
}


/* =========================================================
   MOVING TRACK
========================================================= */

.pillars-strip__track {
  display: flex;
  align-items: center;

  width: max-content;

  gap: clamp(2.5rem, 5vw, 4.5rem);

  animation: pillars-scroll 26s linear infinite;

  will-change: transform;
}


/* =========================================================
   LOGO CONTAINER
   Picha zote 4 sasa zimekatwa (cropped) ili kuondoa uwazi
   (transparent padding) unaozunguka kila mchoro — kabla ya
   hapo, baadhi ya logo (mf. OneVoice27) zilikuwa na uwazi
   mwingi ndani ya PNG kuliko nyingine (mf. I Will Go), hivyo
   hata kwa height moja zilionekana ndogo sana ukilinganisha.
   Baada ya crop, height moja sasa inatoa "uzito" wa kuonekana
   ulio sawa kwa zote nne; width inabaki auto kutokana na
   uwiano wa kila logo (baadhi ni pana zaidi, ni kawaida).
========================================================= */

.pillar-logo {
  flex: 0 0 auto;

  height: 84px;

  display: flex;
  align-items: center;
  justify-content: center;
}


/* =========================================================
   IMAGE
========================================================= */

.pillar-logo img {
  display: block;

  height: 100%;
  width: auto;

  object-fit: contain;

  background: transparent;

  transition: transform 0.3s ease;
}


/* =========================================================
   HOVER
========================================================= */

.pillar-logo:hover img {
  transform: scale(1.06);
}


/* =========================================================
   RIGHT → LEFT
========================================================= */

@keyframes pillars-scroll {
  from {
    transform: translateX(0);
  }

  to {
    transform: translateX(-50%);
  }
}


/* =========================================================
   MOBILE
========================================================= */

@media (max-width: 720px) {
  .pillars-strip {
    height: 96px;
  }

  .pillars-strip__track {
    gap: 1.8rem;
    animation-duration: 20s;
  }

  .pillar-logo {
    height: 58px;
  }
}


/* =========================================================
   REDUCED MOTION
========================================================= */

@media (prefers-reduced-motion: reduce) {
  .pillars-strip__track {
    animation: none;
    transform: translateX(0);
  }
}
</style>