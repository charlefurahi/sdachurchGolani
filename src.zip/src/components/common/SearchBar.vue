<template>
  <div class="relative">
    <svg class="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
    <input :value="modelValue" @input="$emit('update:modelValue', $event.target.value)" type="search" :placeholder="placeholder"
      class="input pl-11 pr-4" />
    <button v-if="modelValue" @click="$emit('update:modelValue', '')" class="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">✕</button>
  </div>
</template>
<script setup>
defineProps({ modelValue: String, placeholder: { type: String, default: 'Search...' } })
defineEmits(['update:modelValue'])
</script>
